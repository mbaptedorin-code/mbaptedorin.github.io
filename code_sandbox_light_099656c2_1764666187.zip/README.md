# 🚚 GIT Cameroon - Green International Trading

Site web moderne et professionnel pour Green International Trading (GIT), entreprise de transport et d'import-export basée à Bali, Douala, Cameroun.

![GIT Cameroon](https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=1200&h=400&fit=crop)

## 📋 Table des Matières

- [À propos du projet](#à-propos-du-projet)
- [Fonctionnalités](#fonctionnalités)
- [Technologies utilisées](#technologies-utilisées)
- [Structure du projet](#structure-du-projet)
- [Installation](#installation)
- [Sections du site](#sections-du-site)
- [Personnalisation](#personnalisation)
- [Performance et optimisation](#performance-et-optimisation)
- [Accessibilité](#accessibilité)
- [Support navigateurs](#support-navigateurs)
- [Prochaines étapes recommandées](#prochaines-étapes-recommandées)

## 🎯 À propos du projet

GIT Cameroon est un site web one-page moderne et responsive conçu pour présenter les services d'import-export et de transport de Green International Trading. Le site met en valeur :

- ✅ Une flotte moderne de véhicules et équipements
- ✅ Des services logistiques complets
- ✅ Une expertise locale au Cameroun
- ✅ Un engagement envers la qualité et la conformité

## ✨ Fonctionnalités

### 🎨 Design et Interface
- **Design moderne et professionnel** avec palette de couleurs verte (thème "Green")
- **Animations fluides** avec AOS (Animate On Scroll)
- **Responsive design** optimisé pour mobile, tablette et desktop
- **Navigation sticky** qui s'adapte au scroll
- **Menu hamburger** pour mobile avec transitions fluides

### 🔄 Interactivité
- **Smooth scrolling** entre les sections
- **Compteurs animés** pour les statistiques (10+ années, 50+ véhicules, etc.)
- **Cards interactives** avec effets hover
- **Formulaire de contact** avec validation côté client
- **Bouton scroll-to-top** qui apparaît au scroll
- **Effet parallax** sur la section hero
- **Ripple effects** sur les boutons

### 📱 Expérience utilisateur
- **Navigation intuitive** avec indication de section active
- **Images optimisées** avec lazy loading
- **Performance optimisée** avec debouncing des événements
- **Accessibilité** (support clavier, focus management)
- **Messages de feedback** pour le formulaire de contact

## 🛠️ Technologies utilisées

### Frontend
- **HTML5** - Structure sémantique moderne
- **CSS3** - Styles avancés avec variables CSS, Flexbox, Grid
- **JavaScript (Vanilla)** - Interactions et animations sans frameworks

### Bibliothèques externes (CDN)
- **Google Fonts** - Poppins & Roboto
- **Font Awesome 6.4.0** - Icônes vectorielles
- **AOS 2.3.4** - Animations au scroll
- **Unsplash** - Images de haute qualité (placeholder)

## 📁 Structure du projet

```
git-cameroon/
├── index.html              # Page principale
├── css/
│   └── style.css          # Styles complets du site
├── js/
│   └── script.js          # Scripts JavaScript
└── README.md              # Documentation (ce fichier)
```

## 🚀 Installation

### Méthode 1 : Utilisation directe
1. Téléchargez tous les fichiers du projet
2. Ouvrez `index.html` dans votre navigateur
3. Le site fonctionne immédiatement sans serveur !

### Méthode 2 : Serveur local (recommandé pour développement)
```bash
# Avec Python 3
python -m http.server 8000

# Avec Node.js (http-server)
npx http-server

# Avec PHP
php -S localhost:8000
```

Puis ouvrez : `http://localhost:8000`

## 📄 Sections du site

### 1. 🏠 Hero Section
- Image de fond avec overlay dégradé vert
- Titre accrocheur et call-to-action
- Boutons pour "Demander un Devis" et "Nos Services"
- Indicateur de scroll animé

### 2. 📊 Statistiques
- 10+ années d'expérience
- 50+ véhicules modernes
- 500+ clients satisfaits
- 1000+ livraisons réussies
- **Compteurs animés** lors du scroll

### 3. 🏢 À Propos
- Présentation de GIT (Green International Trading)
- Localisation : Bali, Douala, Cameroun
- Badge de certification ISO
- Liste des avantages et engagements
- Image principale avec effet hover

### 4. 🛠️ Services
Grille de 6 services principaux :
- Import-Export
- Transport de Marchandises
- Gestion Logistique
- Transport Agricole
- Manutention
- Consultation Logistique

Chaque carte comprend :
- Icône distinctive
- Description détaillée
- Liste des prestations incluses
- Effets hover interactifs

### 5. 🚛 Notre Flotte
Présentation de 6 types de véhicules/équipements :
- Tracteurs et Remorques (20 & 40 pieds)
- Reach Stackers
- Tracteurs Agricoles
- Hysters
- Manitou
- Véhicules Spécialisés

Chaque véhicule dispose de :
- Image de qualité
- Overlay avec icône au hover
- Spécifications techniques
- Tags de caractéristiques

### 6. 🤝 Nos Partenaires
- Industries Leaders
- Compagnies Maritimes
- Entreprises Locales
- Partenaires Internationaux

### 7. ⭐ Témoignages
3 témoignages clients avec :
- Évaluation 5 étoiles
- Citation du client
- Avatar et informations du client
- Design type "card" moderne

### 8. 🎯 Call-to-Action (CTA)
Section avec fond vert et appel à l'action fort :
- Titre impactant
- Message clair
- Bouton "Demander un Devis Gratuit"

### 9. 📧 Contact
Deux colonnes :

**Colonne gauche - Informations :**
- Adresse : Bali, Douala, Cameroun
- Téléphone : +237 XXX XXX XXX
- Email : contact@gitcameroon.cm
- Horaires d'ouverture
- Liens réseaux sociaux

**Colonne droite - Formulaire :**
- Nom complet
- Email
- Téléphone
- Sujet (sélection)
- Message
- Validation en temps réel
- Message de confirmation

### 10. 📄 Footer
4 colonnes :
- Logo et description
- Liens rapides
- Services
- Informations de contact
- Réseaux sociaux
- Copyright et mentions légales

### ➕ Éléments additionnels
- **Bouton Scroll-to-Top** : Apparaît après 300px de scroll
- **Navigation active** : Mise en surbrillance de la section actuelle
- **Menu mobile** : Menu hamburger responsive

## 🎨 Personnalisation

### Couleurs
Les couleurs principales sont définies dans `:root` (CSS variables) :

```css
--primary-green: #2E7D32;        /* Vert principal */
--primary-green-light: #4CAF50;  /* Vert clair */
--primary-green-dark: #1B5E20;   /* Vert foncé */
--secondary-color: #FFA726;      /* Orange secondaire */
```

Pour changer la palette, modifiez ces valeurs dans `css/style.css`.

### Images
Remplacez les URLs Unsplash par vos propres images :
- Images de la flotte
- Image hero (fond)
- Image "À propos"

### Contenu
Modifiez le contenu dans `index.html` :
- Coordonnées (téléphone, email, adresse)
- Textes des sections
- Témoignages clients
- Services offerts

### Typographie
Changez les polices en modifiant les imports Google Fonts :
```html
<link href="https://fonts.googleapis.com/css2?family=VotrePolice&display=swap" rel="stylesheet">
```

## ⚡ Performance et optimisation

### Optimisations implémentées
- ✅ **Lazy loading** pour les images
- ✅ **Debouncing** des événements scroll
- ✅ **CSS optimisé** avec variables et réutilisation
- ✅ **JavaScript optimisé** sans jQuery
- ✅ **CDN** pour les bibliothèques externes
- ✅ **Animations GPU** (transform, opacity)
- ✅ **Compression d'images** recommandée (Unsplash optimisé)

### Recommandations supplémentaires
- [ ] Minifier CSS et JS pour la production
- [ ] Utiliser WebP pour les images
- [ ] Activer la compression GZIP sur le serveur
- [ ] Implémenter un Service Worker pour le cache
- [ ] Utiliser un CDN pour les assets statiques

## ♿ Accessibilité

### Fonctionnalités d'accessibilité
- ✅ Structure HTML sémantique
- ✅ Navigation au clavier (Tab, Escape)
- ✅ Contraste de couleurs conforme WCAG AA
- ✅ Labels pour les formulaires
- ✅ Textes alternatifs pour les images
- ✅ Focus visible sur les éléments interactifs
- ✅ Fermeture du menu avec Escape

### À améliorer
- [ ] Ajouter des attributs ARIA où nécessaire
- [ ] Tester avec lecteurs d'écran (NVDA, JAWS)
- [ ] Ajouter un "skip to content" link
- [ ] Assurer la navigation complète au clavier

## 🌐 Support navigateurs

### Navigateurs supportés
- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Opera 76+
- ✅ Mobile Safari (iOS 14+)
- ✅ Chrome Mobile (Android 10+)

### Fonctionnalités modernes utilisées
- CSS Grid & Flexbox
- CSS Variables
- Intersection Observer (lazy loading)
- ES6+ JavaScript
- CSS Transforms & Animations

## 🔮 Prochaines étapes recommandées

### Court terme
1. **Remplacer les images placeholder** par de vraies photos de la flotte GIT
2. **Ajouter les coordonnées réelles** (téléphone, email, adresse exacte)
3. **Intégrer un système de formulaire** (EmailJS, Formspree, ou backend)
4. **Ajouter Google Maps** pour la localisation
5. **Créer un favicon** personnalisé

### Moyen terme
6. **Système de gestion de contenu** (CMS headless comme Strapi)
7. **Blog/Actualités** pour le SEO et l'engagement
8. **Galerie photos complète** de la flotte avec lightbox
9. **Version multilingue** (Français/Anglais)
10. **Intégration WhatsApp Business** pour contact rapide

### Long terme
11. **Portail client** avec suivi de commandes
12. **Système de devis en ligne** automatisé
13. **Calculateur de tarifs** pour estimations instantanées
14. **Espace partenaires** avec login
15. **Application mobile** (PWA ou native)
16. **Chatbot** pour réponses automatiques
17. **Système de réservation** en ligne

## 📈 SEO et Marketing

### Optimisations SEO à implémenter
- [ ] Meta tags OpenGraph pour réseaux sociaux
- [ ] Schema.org markup (LocalBusiness)
- [ ] Sitemap.xml
- [ ] Robots.txt
- [ ] Google Analytics
- [ ] Google Search Console
- [ ] Backlinks depuis annuaires locaux

### Marketing digital
- [ ] Page Google My Business
- [ ] Présence sur réseaux sociaux (Facebook, LinkedIn, Instagram)
- [ ] Campagnes Google Ads locales
- [ ] Email marketing (newsletter)
- [ ] Témoignages clients vidéo

## 🛡️ Sécurité

### Mesures de sécurité
- ✅ Validation côté client du formulaire
- ⚠️ **À implémenter** : Validation côté serveur
- ⚠️ **À implémenter** : Protection anti-spam (reCAPTCHA)
- ⚠️ **À implémenter** : HTTPS/SSL obligatoire
- ⚠️ **À implémenter** : Politique de sécurité du contenu (CSP)
- ⚠️ **À implémenter** : Protection contre CSRF

## 📞 Support et Contact

Pour toute question concernant ce projet :

**Green International Trading (GIT)**
- 📍 Adresse : Bali, Douala, Cameroun
- 📞 Téléphone : +237 XXX XXX XXX
- 📧 Email : contact@gitcameroon.cm
- 🌐 Site web : https://gitcameroon.cm/

---

## 📝 Licence

© 2024 Green International Trading (GIT). Tous droits réservés.

---

## 🙏 Crédits

- **Design & Développement** : Équipe GIT Web
- **Images** : Unsplash (placeholder - à remplacer)
- **Icônes** : Font Awesome
- **Polices** : Google Fonts (Poppins & Roboto)
- **Animations** : AOS Library

---

**Fait avec ❤️ pour GIT Cameroon - Votre partenaire de confiance pour l'import-export et le transport**

🚀 **Version actuelle** : 1.0.0  
📅 **Dernière mise à jour** : Décembre 2024